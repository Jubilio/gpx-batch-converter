# GPX Batch Converter

Version 1.0.3

A QGIS plugin for converting GPX layers to ESRI Shapefiles in batch.

## Features

- Select an input folder containing GPX files.
- Select an output folder.
- Convert:
  - waypoints
  - routes
  - route points
  - tracks
  - track points
- Overwrite existing outputs.
- Optionally add converted layers to the current QGIS project.
- Display progress and conversion messages.
- Runs directly inside QGIS without manually opening OSGeo4W Shell.

## Installation

1. Open QGIS.
2. Go to **Plugins > Manage and Install Plugins**.
3. Select **Install from ZIP**.
4. Select `gpx_batch_converter_v1.0.0.zip`.
5. Approve the security warning for a locally created plugin if QGIS displays one.
6. Enable **GPX Batch Converter**.

The plugin is available from the **Vector** menu and the plugin toolbar.

## Supported QGIS versions

QGIS 3.28 or later.


## Version 1.0.1

- Fixed folder selection in QGIS 4 / Qt 6.
- Added compatibility for scoped Qt cursor enums.
- Added compatibility for QGIS vector-writer and message-level enums.
- Retains compatibility with QGIS 3.28 or later.


## Version 1.0.2

- Added a custom icon to the QGIS toolbar action.
- Added the icon to the Vector menu action.
- Added the icon to the plugin dialog window.
- Added the icon to the QGIS Plugin Manager metadata.


## Version 1.0.3

- Declared explicit compatibility with QGIS 3.28 through QGIS 4.99.
- Added `supportsQt6=True` for QGIS 4 / Qt 6.
- Fixed the final notification crash caused by a local variable shadowing
  the `message_level` helper function.
- Successful conversions are preserved; the previous error occurred only
  while displaying the completion notification.
