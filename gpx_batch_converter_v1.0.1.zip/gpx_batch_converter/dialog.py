from pathlib import Path
import re

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from qgis.core import (
    Qgis,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)


def qt_wait_cursor():
    """Return the wait cursor enum in Qt 5 or Qt 6."""
    cursor_shape = getattr(Qt, "CursorShape", None)
    if cursor_shape is not None:
        return cursor_shape.WaitCursor
    return Qt.WaitCursor


def writer_no_error():
    """Return the vector writer success enum in QGIS 3 or QGIS 4."""
    writer_error = getattr(QgsVectorFileWriter, "WriterError", None)
    if writer_error is not None:
        return writer_error.NoError
    return QgsVectorFileWriter.NoError


def message_level(name):
    """Return a QGIS message level in old or scoped enum form."""
    scoped_enum = getattr(Qgis, "MessageLevel", None)
    if scoped_enum is not None:
        return getattr(scoped_enum, name)
    return getattr(Qgis, name)


class FolderSelector(QWidget):
    """Line edit and Browse button for selecting a folder."""

    def __init__(self, dialog_title, parent=None):
        super().__init__(parent)
        self.dialog_title = dialog_title

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Select or paste a folder path")

        self.browse_button = QPushButton("Browse...")
        self.browse_button.clicked.connect(self.browse)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.path_edit, 1)
        layout.addWidget(self.browse_button)

    def browse(self):
        current_path = self.path_edit.text().strip()
        start_folder = (
            current_path
            if current_path and Path(current_path).is_dir()
            else str(Path.home())
        )

        selected_folder = QFileDialog.getExistingDirectory(
            self,
            self.dialog_title,
            start_folder,
        )

        if selected_folder:
            self.path_edit.setText(selected_folder)

    def path(self):
        return Path(
            self.path_edit.text().strip().strip('"').strip("'")
        )


class GpxBatchConverterDialog(QDialog):
    """Graphical interface for batch GPX conversion."""

    LAYER_OPTIONS = (
        ("waypoints", "Waypoints"),
        ("routes", "Routes"),
        ("route_points", "Route points"),
        ("tracks", "Tracks"),
        ("track_points", "Track points"),
    )

    SHAPEFILE_COMPONENTS = (
        ".shp",
        ".shx",
        ".dbf",
        ".prj",
        ".cpg",
        ".qpj",
        ".sbn",
        ".sbx",
    )

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("GPX Batch Converter")
        self.setMinimumWidth(680)
        self.resize(760, 620)

        self.input_selector = FolderSelector(
            "Select the folder containing GPX files"
        )
        self.output_selector = FolderSelector(
            "Select the output folder"
        )

        self.layer_checkboxes = {}
        for layer_name, label in self.LAYER_OPTIONS:
            checkbox = QCheckBox(label)
            checkbox.setChecked(
                layer_name in {"tracks", "track_points"}
            )
            self.layer_checkboxes[layer_name] = checkbox

        self.add_to_project_checkbox = QCheckBox(
            "Add converted Shapefiles to the current QGIS project"
        )
        self.add_to_project_checkbox.setChecked(True)

        self.overwrite_checkbox = QCheckBox(
            "Overwrite existing Shapefiles"
        )
        self.overwrite_checkbox.setChecked(True)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)

        self.status_label = QLabel("Ready.")
        self.status_label.setWordWrap(True)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setPlaceholderText(
            "Conversion messages will appear here."
        )

        self.convert_button = QPushButton("Convert")
        self.convert_button.setDefault(True)
        self.convert_button.clicked.connect(self.convert)

        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.close)

        self._build_layout()

    def _build_layout(self):
        main_layout = QVBoxLayout(self)

        intro = QLabel(
            "Convert GPX files in a folder to ESRI Shapefiles. "
            "The plugin runs directly inside QGIS and does not require "
            "opening the OSGeo4W Shell."
        )
        intro.setWordWrap(True)
        main_layout.addWidget(intro)

        folder_group = QGroupBox("Folders")
        folder_layout = QFormLayout(folder_group)
        folder_layout.addRow("Input folder:", self.input_selector)
        folder_layout.addRow("Output folder:", self.output_selector)
        main_layout.addWidget(folder_group)

        layer_group = QGroupBox("GPX layers to convert")
        layer_layout = QVBoxLayout(layer_group)
        for layer_name, _ in self.LAYER_OPTIONS:
            layer_layout.addWidget(
                self.layer_checkboxes[layer_name]
            )
        main_layout.addWidget(layer_group)

        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout(options_group)
        options_layout.addWidget(self.overwrite_checkbox)
        options_layout.addWidget(self.add_to_project_checkbox)
        main_layout.addWidget(options_group)

        main_layout.addWidget(self.progress_bar)
        main_layout.addWidget(self.status_label)
        main_layout.addWidget(self.log_output, 1)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.convert_button)
        button_layout.addWidget(self.close_button)
        main_layout.addLayout(button_layout)

    def selected_layers(self):
        return [
            layer_name
            for layer_name, checkbox
            in self.layer_checkboxes.items()
            if checkbox.isChecked()
        ]

    @staticmethod
    def clean_filename(name):
        cleaned = re.sub(
            r"[^\w\s-]",
            "",
            name,
            flags=re.UNICODE
        )
        cleaned = re.sub(
            r"\s+",
            "_",
            cleaned.strip()
        )
        return cleaned[:80] or "gpx_layer"

    def remove_existing_shapefile(self, shp_path):
        for extension in self.SHAPEFILE_COMPONENTS:
            component = shp_path.with_suffix(extension)
            if component.exists():
                component.unlink()

    def log(self, message):
        self.log_output.append(message)
        self.log_output.ensureCursorVisible()
        QApplication.processEvents()

    def set_busy(self, busy):
        self.convert_button.setEnabled(not busy)
        self.close_button.setEnabled(not busy)
        self.input_selector.setEnabled(not busy)
        self.output_selector.setEnabled(not busy)

        for checkbox in self.layer_checkboxes.values():
            checkbox.setEnabled(not busy)

        self.overwrite_checkbox.setEnabled(not busy)
        self.add_to_project_checkbox.setEnabled(not busy)

        if busy:
            QApplication.setOverrideCursor(qt_wait_cursor())
        else:
            QApplication.restoreOverrideCursor()

    def validate_inputs(self):
        input_text = self.input_selector.path_edit.text().strip()
        output_text = self.output_selector.path_edit.text().strip()

        if not input_text:
            QMessageBox.warning(
                self,
                "Invalid input folder",
                "Select the folder containing the GPX files."
            )
            return None

        if not output_text:
            QMessageBox.warning(
                self,
                "Invalid output folder",
                "Select a folder for the converted Shapefiles."
            )
            return None

        input_folder = self.input_selector.path()
        output_folder = self.output_selector.path()
        selected_layers = self.selected_layers()

        if not input_folder.exists() or not input_folder.is_dir():
            QMessageBox.warning(
                self,
                "Invalid input folder",
                "Select an existing folder containing GPX files."
            )
            return None

        if not selected_layers:
            QMessageBox.warning(
                self,
                "No GPX layer selected",
                "Select at least one GPX layer to convert."
            )
            return None

        try:
            output_folder.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            QMessageBox.critical(
                self,
                "Output folder error",
                f"The output folder could not be created:\n{error}"
            )
            return None

        gpx_files = sorted(
            file
            for file in input_folder.iterdir()
            if file.is_file() and file.suffix.lower() == ".gpx"
        )

        if not gpx_files:
            QMessageBox.information(
                self,
                "No GPX files",
                "No GPX files were found in the selected input folder."
            )
            return None

        return (
            input_folder,
            output_folder,
            selected_layers,
            gpx_files,
        )

    def convert(self):
        validated = self.validate_inputs()
        if validated is None:
            return

        (
            input_folder,
            output_folder,
            selected_layers,
            gpx_files,
        ) = validated

        self.log_output.clear()
        self.progress_bar.setValue(0)
        self.set_busy(True)

        successful = 0
        skipped = 0
        failed = 0
        total_operations = len(gpx_files) * len(selected_layers)
        completed_operations = 0

        self.log(
            f"<b>Input folder:</b> {input_folder}<br>"
            f"<b>Output folder:</b> {output_folder}<br>"
            f"<b>GPX files:</b> {len(gpx_files)}<br>"
            f"<b>Selected layers:</b> "
            f"{', '.join(selected_layers)}<br>"
        )

        try:
            for file_index, gpx_file in enumerate(
                gpx_files,
                start=1
            ):
                base_name = self.clean_filename(gpx_file.stem)
                self.status_label.setText(
                    f"Processing {file_index} of "
                    f"{len(gpx_files)}: {gpx_file.name}"
                )
                self.log(
                    f"<br><b>[{file_index}/{len(gpx_files)}] "
                    f"{gpx_file.name}</b>"
                )

                for layer_name in selected_layers:
                    completed_operations += 1
                    progress = int(
                        completed_operations
                        / total_operations
                        * 100
                    )
                    self.progress_bar.setValue(progress)
                    QApplication.processEvents()

                    source_uri = (
                        f"{gpx_file}|layername={layer_name}"
                    )
                    source_layer = QgsVectorLayer(
                        source_uri,
                        f"{base_name}_{layer_name}",
                        "ogr"
                    )

                    if (
                        not source_layer.isValid()
                        or source_layer.featureCount() == 0
                    ):
                        self.log(
                            f"&nbsp;&nbsp;Skipped: "
                            f"{layer_name} "
                            f"(missing or empty)"
                        )
                        skipped += 1
                        continue

                    output_shp = (
                        output_folder
                        / f"{base_name}_{layer_name}.shp"
                    )

                    if output_shp.exists():
                        if self.overwrite_checkbox.isChecked():
                            try:
                                self.remove_existing_shapefile(
                                    output_shp
                                )
                            except OSError as error:
                                self.log(
                                    f"&nbsp;&nbsp;<span style='color:red'>"
                                    f"Failed: {layer_name} — "
                                    f"could not remove the existing file: "
                                    f"{error}</span>"
                                )
                                failed += 1
                                continue
                        else:
                            self.log(
                                f"&nbsp;&nbsp;Skipped: "
                                f"{layer_name} "
                                f"(output already exists)"
                            )
                            skipped += 1
                            continue

                    save_options = (
                        QgsVectorFileWriter.SaveVectorOptions()
                    )
                    save_options.driverName = "ESRI Shapefile"
                    save_options.fileEncoding = "UTF-8"
                    save_options.layerName = output_shp.stem

                    result = (
                        QgsVectorFileWriter.writeAsVectorFormatV3(
                            source_layer,
                            str(output_shp),
                            QgsProject.instance().transformContext(),
                            save_options,
                        )
                    )

                    error_code = result[0]
                    error_message = (
                        result[1]
                        if len(result) > 1 and result[1]
                        else "Unknown QGIS writer error."
                    )

                    if error_code == writer_no_error():
                        self.log(
                            f"&nbsp;&nbsp;OK: "
                            f"{output_shp.name}"
                        )
                        successful += 1

                        if (
                            self.add_to_project_checkbox.isChecked()
                        ):
                            output_layer = QgsVectorLayer(
                                str(output_shp),
                                output_shp.stem,
                                "ogr"
                            )
                            if output_layer.isValid():
                                QgsProject.instance().addMapLayer(
                                    output_layer
                                )
                    else:
                        self.log(
                            f"&nbsp;&nbsp;<span style='color:red'>"
                            f"Failed: {layer_name} — "
                            f"{error_message}</span>"
                        )
                        failed += 1

            self.progress_bar.setValue(100)
            self.status_label.setText("Conversion completed.")

            summary = (
                f"Converted: {successful}\n"
                f"Skipped: {skipped}\n"
                f"Failed: {failed}\n\n"
                f"Output folder:\n{output_folder}"
            )

            if failed:
                message_level = message_level("Warning")
                title = "Conversion completed with errors"
            else:
                message_level = message_level("Success")
                title = "Conversion completed"

            self.iface.messageBar().pushMessage(
                title,
                (
                    f"{successful} converted, "
                    f"{skipped} skipped, "
                    f"{failed} failed."
                ),
                level=message_level,
                duration=8,
            )

            QMessageBox.information(
                self,
                title,
                summary
            )

        except Exception as error:
            self.progress_bar.setValue(0)
            self.status_label.setText("Conversion stopped.")
            self.log(
                f"<br><span style='color:red'><b>"
                f"Unexpected error:</b> {error}</span>"
            )
            QMessageBox.critical(
                self,
                "Unexpected error",
                str(error)
            )
        finally:
            self.set_busy(False)
