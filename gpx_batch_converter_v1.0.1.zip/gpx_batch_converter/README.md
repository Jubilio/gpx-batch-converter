# GPX Batch Converter

Version 1.0.1

A QGIS plugin for converting GPX layers to ESRI Shapefiles in batch.

## Features

- Select an input folder containing GPX files.
- Select an output folder.
- Convert:
  - waypoints
  - routes
  - route points
  - tracks
  - track points
- Overwrite existing outputs.
- Optionally add converted layers to the current QGIS project.
- Display progress and conversion messages.
- Runs directly inside QGIS without manually opening OSGeo4W Shell.

## Installation

1. Open QGIS.
2. Go to **Plugins > Manage and Install Plugins**.
3. Select **Install from ZIP**.
4. Select `gpx_batch_converter_v1.0.0.zip`.
5. Approve the security warning for a locally created plugin if QGIS displays one.
6. Enable **GPX Batch Converter**.

The plugin is available from the **Vector** menu and the plugin toolbar.

## Supported QGIS versions

QGIS 3.28 or later.


## Version 1.0.1

- Fixed folder selection in QGIS 4 / Qt 6.
- Added compatibility for scoped Qt cursor enums.
- Added compatibility for QGIS vector-writer and message-level enums.
- Retains compatibility with QGIS 3.28 or later.
