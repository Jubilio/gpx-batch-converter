from pathlib import Path
import re

import processing

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)


def qt_wait_cursor():
    """Return the wait cursor enum in Qt 5 or Qt 6."""
    cursor_shape = getattr(Qt, "CursorShape", None)
    if cursor_shape is not None:
        return cursor_shape.WaitCursor
    return Qt.WaitCursor


def writer_no_error():
    """Return the vector writer success enum in QGIS 3 or QGIS 4."""
    writer_error = getattr(QgsVectorFileWriter, "WriterError", None)
    if writer_error is not None:
        return writer_error.NoError
    return QgsVectorFileWriter.NoError


def qgis_message_level(name):
    """Return a QGIS message level in old or scoped enum form."""
    scoped_enum = getattr(Qgis, "MessageLevel", None)
    if scoped_enum is not None:
        return getattr(scoped_enum, name)
    return getattr(Qgis, name)


class FolderSelector(QWidget):
    """Line edit and Browse button for selecting a folder."""

    def __init__(self, dialog_title, parent=None):
        super().__init__(parent)
        self.dialog_title = dialog_title

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Select or paste a folder path")

        self.browse_button = QPushButton("Browse...")
        self.browse_button.clicked.connect(self.browse)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.path_edit, 1)
        layout.addWidget(self.browse_button)

    def browse(self):
        current_path = self.path_edit.text().strip()
        start_folder = (
            current_path
            if current_path and Path(current_path).is_dir()
            else str(Path.home())
        )

        selected_folder = QFileDialog.getExistingDirectory(
            self,
            self.dialog_title,
            start_folder,
        )

        if selected_folder:
            self.path_edit.setText(selected_folder)

    def path(self):
        return Path(
            self.path_edit.text().strip().strip('"').strip("'")
        )


class GpxBatchConverterDialog(QDialog):
    """Graphical interface for batch GPX conversion."""

    LAYER_OPTIONS = (
        ("waypoints", "Waypoints"),
        ("routes", "Routes"),
        ("route_points", "Route points"),
        ("tracks", "Tracks"),
        ("track_points", "Track points"),
    )

    SHAPEFILE_COMPONENTS = (
        ".shp",
        ".shx",
        ".dbf",
        ".prj",
        ".cpg",
        ".qpj",
        ".sbn",
        ".sbx",
    )

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("GPX Batch Converter")
        self.setWindowIcon(
            QIcon(str(Path(__file__).resolve().parent / "icon.png"))
        )
        self.setMinimumWidth(700)
        self.resize(780, 680)

        self.input_selector = FolderSelector(
            "Select the folder containing GPX files"
        )
        self.output_selector = FolderSelector(
            "Select the output folder"
        )

        self.layer_checkboxes = {}
        for layer_name, label in self.LAYER_OPTIONS:
            checkbox = QCheckBox(label)
            checkbox.setChecked(
                layer_name in {"tracks", "track_points"}
            )
            self.layer_checkboxes[layer_name] = checkbox

        self.merge_checkbox = QCheckBox(
            "Merge all GPX files into one output per layer type"
        )
        self.merge_checkbox.setToolTip(
            "Creates outputs such as merged_tracks.shp and "
            "merged_track_points.shp instead of one Shapefile per GPX file."
        )
        self.merge_checkbox.setChecked(False)
        self.merge_checkbox.toggled.connect(
            self.update_merge_controls
        )

        self.merge_prefix_edit = QLineEdit("merged")
        self.merge_prefix_edit.setPlaceholderText(
            "Prefix for merged outputs"
        )
        self.merge_prefix_edit.setToolTip(
            "Example: survey creates survey_tracks.shp."
        )
        self.merge_prefix_edit.setEnabled(False)

        self.add_to_project_checkbox = QCheckBox(
            "Add converted Shapefiles to the current QGIS project"
        )
        self.add_to_project_checkbox.setChecked(True)

        self.overwrite_checkbox = QCheckBox(
            "Overwrite existing Shapefiles"
        )
        self.overwrite_checkbox.setChecked(True)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)

        self.status_label = QLabel("Ready.")
        self.status_label.setWordWrap(True)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setPlaceholderText(
            "Conversion messages will appear here."
        )

        self.convert_button = QPushButton("Convert")
        self.convert_button.setDefault(True)
        self.convert_button.clicked.connect(self.convert)

        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.close)

        self._build_layout()

    def _build_layout(self):
        main_layout = QVBoxLayout(self)

        intro = QLabel(
            "Convert GPX files in a folder to ESRI Shapefiles. "
            "You can create one output per GPX file or merge all files "
            "into one output for each selected GPX layer type."
        )
        intro.setWordWrap(True)
        main_layout.addWidget(intro)

        folder_group = QGroupBox("Folders")
        folder_layout = QFormLayout(folder_group)
        folder_layout.addRow("Input folder:", self.input_selector)
        folder_layout.addRow("Output folder:", self.output_selector)
        main_layout.addWidget(folder_group)

        layer_group = QGroupBox("GPX layers to convert")
        layer_layout = QVBoxLayout(layer_group)
        for layer_name, _ in self.LAYER_OPTIONS:
            layer_layout.addWidget(
                self.layer_checkboxes[layer_name]
            )
        main_layout.addWidget(layer_group)

        options_group = QGroupBox("Options")
        options_layout = QFormLayout(options_group)
        options_layout.addRow(self.overwrite_checkbox)
        options_layout.addRow(self.add_to_project_checkbox)
        options_layout.addRow(self.merge_checkbox)
        options_layout.addRow(
            "Merged output prefix:",
            self.merge_prefix_edit,
        )
        main_layout.addWidget(options_group)

        main_layout.addWidget(self.progress_bar)
        main_layout.addWidget(self.status_label)
        main_layout.addWidget(self.log_output, 1)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.convert_button)
        button_layout.addWidget(self.close_button)
        main_layout.addLayout(button_layout)

    def update_merge_controls(self):
        self.merge_prefix_edit.setEnabled(
            self.merge_checkbox.isChecked()
            and self.convert_button.isEnabled()
        )

    def selected_layers(self):
        return [
            layer_name
            for layer_name, checkbox
            in self.layer_checkboxes.items()
            if checkbox.isChecked()
        ]

    @staticmethod
    def clean_filename(name, fallback="gpx_layer"):
        cleaned = re.sub(
            r"[^\w\s-]",
            "",
            name,
            flags=re.UNICODE,
        )
        cleaned = re.sub(
            r"\s+",
            "_",
            cleaned.strip(),
        )
        return cleaned[:80] or fallback

    def remove_existing_shapefile(self, shp_path):
        for extension in self.SHAPEFILE_COMPONENTS:
            component = shp_path.with_suffix(extension)
            if component.exists():
                component.unlink()

    def log(self, message):
        self.log_output.append(message)
        self.log_output.ensureCursorVisible()
        QApplication.processEvents()

    def set_busy(self, busy):
        self.convert_button.setEnabled(not busy)
        self.close_button.setEnabled(not busy)
        self.input_selector.setEnabled(not busy)
        self.output_selector.setEnabled(not busy)

        for checkbox in self.layer_checkboxes.values():
            checkbox.setEnabled(not busy)

        self.overwrite_checkbox.setEnabled(not busy)
        self.add_to_project_checkbox.setEnabled(not busy)
        self.merge_checkbox.setEnabled(not busy)
        self.merge_prefix_edit.setEnabled(
            not busy and self.merge_checkbox.isChecked()
        )

        if busy:
            QApplication.setOverrideCursor(qt_wait_cursor())
        else:
            QApplication.restoreOverrideCursor()

    def validate_inputs(self):
        input_text = self.input_selector.path_edit.text().strip()
        output_text = self.output_selector.path_edit.text().strip()

        if not input_text:
            QMessageBox.warning(
                self,
                "Invalid input folder",
                "Select the folder containing the GPX files.",
            )
            return None

        if not output_text:
            QMessageBox.warning(
                self,
                "Invalid output folder",
                "Select a folder for the converted Shapefiles.",
            )
            return None

        input_folder = self.input_selector.path()
        output_folder = self.output_selector.path()
        selected_layers = self.selected_layers()
        merge_mode = self.merge_checkbox.isChecked()

        if not input_folder.exists() or not input_folder.is_dir():
            QMessageBox.warning(
                self,
                "Invalid input folder",
                "Select an existing folder containing GPX files.",
            )
            return None

        if not selected_layers:
            QMessageBox.warning(
                self,
                "No GPX layer selected",
                "Select at least one GPX layer to convert.",
            )
            return None

        merge_prefix = ""
        if merge_mode:
            prefix_text = self.merge_prefix_edit.text().strip()
            if not prefix_text:
                QMessageBox.warning(
                    self,
                    "Missing output prefix",
                    "Enter a prefix for the merged output files.",
                )
                return None
            merge_prefix = self.clean_filename(
                prefix_text,
                fallback="merged",
            )

        try:
            output_folder.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            QMessageBox.critical(
                self,
                "Output folder error",
                f"The output folder could not be created:\n{error}",
            )
            return None

        gpx_files = sorted(
            file
            for file in input_folder.iterdir()
            if file.is_file() and file.suffix.lower() == ".gpx"
        )

        if not gpx_files:
            QMessageBox.information(
                self,
                "No GPX files",
                "No GPX files were found in the selected input folder.",
            )
            return None

        return (
            input_folder,
            output_folder,
            selected_layers,
            gpx_files,
            merge_mode,
            merge_prefix,
        )

    def create_source_layer(self, gpx_file, layer_name):
        base_name = self.clean_filename(gpx_file.stem)
        source_uri = f"{gpx_file}|layername={layer_name}"

        source_layer = QgsVectorLayer(
            source_uri,
            base_name,
            "ogr",
        )

        if (
            not source_layer.isValid()
            or source_layer.featureCount() == 0
        ):
            return None

        return source_layer

    def prepare_output(self, output_shp):
        if not output_shp.exists():
            return True, ""

        if not self.overwrite_checkbox.isChecked():
            return False, "output already exists"

        try:
            self.remove_existing_shapefile(output_shp)
        except OSError as error:
            return False, (
                "could not remove the existing output: "
                f"{error}"
            )

        return True, ""

    def write_vector_layer(self, source_layer, output_shp):
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "ESRI Shapefile"
        save_options.fileEncoding = "UTF-8"
        save_options.layerName = output_shp.stem

        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            source_layer,
            str(output_shp),
            QgsProject.instance().transformContext(),
            save_options,
        )

        error_code = result[0]
        error_message = (
            result[1]
            if len(result) > 1 and result[1]
            else "Unknown QGIS writer error."
        )

        return error_code == writer_no_error(), error_message

    def add_output_to_project(self, output_shp):
        if not self.add_to_project_checkbox.isChecked():
            return

        output_layer = QgsVectorLayer(
            str(output_shp),
            output_shp.stem,
            "ogr",
        )
        if output_layer.isValid():
            QgsProject.instance().addMapLayer(output_layer)

    def merge_vector_layers(self, source_layers, output_shp):
        algorithm = (
            QgsApplication.processingRegistry().algorithmById(
                "native:mergevectorlayers"
            )
        )

        if algorithm is None:
            raise RuntimeError(
                "The QGIS Merge vector layers algorithm is unavailable."
            )

        parameter_names = {
            parameter.name()
            for parameter in algorithm.parameterDefinitions()
        }

        parameters = {
            "LAYERS": source_layers,
            "CRS": None,
            "OUTPUT": str(output_shp),
        }

        # Available in recent QGIS versions, including QGIS 4.
        # It adds fields containing the original layer name and source path.
        if "ADD_SOURCE_FIELDS" in parameter_names:
            parameters["ADD_SOURCE_FIELDS"] = True

        processing.run(
            "native:mergevectorlayers",
            parameters,
        )

        if not output_shp.exists():
            raise RuntimeError(
                "QGIS completed the merge algorithm, but the output "
                "Shapefile was not created."
            )

    def convert_individual(
        self,
        output_folder,
        selected_layers,
        gpx_files,
    ):
        successful = 0
        missing_empty = 0
        existing_skipped = 0
        failed = 0

        total_operations = len(gpx_files) * len(selected_layers)
        completed_operations = 0

        for file_index, gpx_file in enumerate(gpx_files, start=1):
            base_name = self.clean_filename(gpx_file.stem)

            self.status_label.setText(
                f"Processing {file_index} of "
                f"{len(gpx_files)}: {gpx_file.name}"
            )
            self.log(
                f"<br><b>[{file_index}/{len(gpx_files)}] "
                f"{gpx_file.name}</b>"
            )

            for layer_name in selected_layers:
                completed_operations += 1
                progress = int(
                    completed_operations
                    / total_operations
                    * 100
                )
                self.progress_bar.setValue(progress)
                QApplication.processEvents()

                source_layer = self.create_source_layer(
                    gpx_file,
                    layer_name,
                )

                if source_layer is None:
                    self.log(
                        f"Skipped: {layer_name} "
                        f"(missing or empty)"
                    )
                    missing_empty += 1
                    continue

                output_shp = (
                    output_folder
                    / f"{base_name}_{layer_name}.shp"
                )

                can_write, reason = self.prepare_output(
                    output_shp
                )
                if not can_write:
                    if reason == "output already exists":
                        self.log(
                            f"Skipped: {layer_name} ({reason})"
                        )
                        existing_skipped += 1
                    else:
                        self.log(
                            f"<span style='color:red'>"
                            f"Failed: {layer_name} — "
                            f"{reason}</span>"
                        )
                        failed += 1
                    continue

                succeeded, error_message = (
                    self.write_vector_layer(
                        source_layer,
                        output_shp,
                    )
                )

                if succeeded:
                    self.log(f"OK: {output_shp.name}")
                    successful += 1
                    self.add_output_to_project(output_shp)
                else:
                    self.log(
                        f"<span style='color:red'>"
                        f"Failed: {layer_name} — "
                        f"{error_message}</span>"
                    )
                    failed += 1

        return {
            "converted": successful,
            "missing_empty": missing_empty,
            "existing_skipped": existing_skipped,
            "failed": failed,
            "source_layers": successful,
        }

    def convert_merged(
        self,
        output_folder,
        selected_layers,
        gpx_files,
        merge_prefix,
    ):
        merged_outputs = 0
        source_layers_included = 0
        missing_empty = 0
        existing_skipped = 0
        failed = 0

        total_operations = (
            len(selected_layers) * (len(gpx_files) + 1)
        )
        completed_operations = 0

        for layer_index, layer_name in enumerate(
            selected_layers,
            start=1,
        ):
            self.log(
                f"<br><b>[{layer_index}/{len(selected_layers)}] "
                f"Collecting {layer_name}</b>"
            )

            source_layers = []
            missing_for_layer = 0

            for file_index, gpx_file in enumerate(
                gpx_files,
                start=1,
            ):
                self.status_label.setText(
                    f"Scanning {layer_name}: "
                    f"{file_index} of {len(gpx_files)}"
                )

                source_layer = self.create_source_layer(
                    gpx_file,
                    layer_name,
                )

                if source_layer is None:
                    missing_empty += 1
                    missing_for_layer += 1
                else:
                    source_layers.append(source_layer)
                    source_layers_included += 1

                completed_operations += 1
                self.progress_bar.setValue(
                    int(
                        completed_operations
                        / total_operations
                        * 100
                    )
                )
                QApplication.processEvents()

            self.log(
                f"Found {len(source_layers)} non-empty "
                f"{layer_name} layers; "
                f"{missing_for_layer} missing or empty."
            )

            completed_operations += 1
            self.progress_bar.setValue(
                int(
                    completed_operations
                    / total_operations
                    * 100
                )
            )
            QApplication.processEvents()

            if not source_layers:
                self.log(
                    f"Skipped merged {layer_name}: "
                    f"no non-empty source layers were found."
                )
                continue

            output_shp = (
                output_folder
                / f"{merge_prefix}_{layer_name}.shp"
            )

            can_write, reason = self.prepare_output(
                output_shp
            )
            if not can_write:
                if reason == "output already exists":
                    self.log(
                        f"Skipped: {output_shp.name} ({reason})"
                    )
                    existing_skipped += 1
                else:
                    self.log(
                        f"<span style='color:red'>"
                        f"Failed: {output_shp.name} — "
                        f"{reason}</span>"
                    )
                    failed += 1
                continue

            self.status_label.setText(
                f"Merging {len(source_layers)} "
                f"{layer_name} layers..."
            )
            QApplication.processEvents()

            try:
                self.merge_vector_layers(
                    source_layers,
                    output_shp,
                )
                self.log(
                    f"OK: {output_shp.name} "
                    f"({len(source_layers)} source layers)"
                )
                merged_outputs += 1
                self.add_output_to_project(output_shp)
            except Exception as error:
                self.log(
                    f"<span style='color:red'>"
                    f"Failed: {output_shp.name} — "
                    f"{error}</span>"
                )
                failed += 1

        return {
            "converted": merged_outputs,
            "missing_empty": missing_empty,
            "existing_skipped": existing_skipped,
            "failed": failed,
            "source_layers": source_layers_included,
        }

    def show_summary(
        self,
        results,
        output_folder,
        merge_mode,
    ):
        self.progress_bar.setValue(100)
        self.status_label.setText("Conversion completed.")

        if merge_mode:
            summary = (
                f"Merged outputs created: "
                f"{results['converted']}\n"
                f"Source layers included: "
                f"{results['source_layers']}\n"
                f"Missing or empty layers: "
                f"{results['missing_empty']}\n"
                f"Existing outputs skipped: "
                f"{results['existing_skipped']}\n"
                f"Failed outputs: "
                f"{results['failed']}\n\n"
                f"Output folder:\n{output_folder}"
            )
            message_text = (
                f"{results['converted']} merged outputs, "
                f"{results['source_layers']} source layers, "
                f"{results['failed']} failed."
            )
        else:
            summary = (
                f"Layers converted: {results['converted']}\n"
                f"Missing or empty layers: "
                f"{results['missing_empty']}\n"
                f"Existing outputs skipped: "
                f"{results['existing_skipped']}\n"
                f"Failed conversions: "
                f"{results['failed']}\n\n"
                f"Output folder:\n{output_folder}"
            )
            message_text = (
                f"{results['converted']} converted, "
                f"{results['missing_empty']} missing/empty, "
                f"{results['failed']} failed."
            )

        if results["failed"]:
            notification_level = qgis_message_level("Warning")
            title = "Conversion completed with errors"
        else:
            notification_level = qgis_message_level("Success")
            title = "Conversion completed"

        self.iface.messageBar().pushMessage(
            title,
            message_text,
            level=notification_level,
            duration=10,
        )

        QMessageBox.information(
            self,
            title,
            summary,
        )

    def convert(self):
        validated = self.validate_inputs()
        if validated is None:
            return

        (
            input_folder,
            output_folder,
            selected_layers,
            gpx_files,
            merge_mode,
            merge_prefix,
        ) = validated

        self.log_output.clear()
        self.progress_bar.setValue(0)
        self.set_busy(True)

        mode_label = (
            "Merged outputs"
            if merge_mode
            else "One output per GPX file"
        )

        self.log(
            f"<b>Input folder:</b> {input_folder}<br>"
            f"<b>Output folder:</b> {output_folder}<br>"
            f"<b>GPX files:</b> {len(gpx_files)}<br>"
            f"<b>Selected layers:</b> "
            f"{', '.join(selected_layers)}<br>"
            f"<b>Mode:</b> {mode_label}<br>"
        )

        try:
            if merge_mode:
                results = self.convert_merged(
                    output_folder,
                    selected_layers,
                    gpx_files,
                    merge_prefix,
                )
            else:
                results = self.convert_individual(
                    output_folder,
                    selected_layers,
                    gpx_files,
                )

            self.show_summary(
                results,
                output_folder,
                merge_mode,
            )

        except Exception as error:
            self.progress_bar.setValue(0)
            self.status_label.setText("Conversion stopped.")
            self.log(
                f"<br><span style='color:red'><b>"
                f"Unexpected error:</b> {error}</span>"
            )
            QMessageBox.critical(
                self,
                "Unexpected error",
                str(error),
            )
        finally:
            self.set_busy(False)
